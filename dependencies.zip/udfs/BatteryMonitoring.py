# from pyflink.datastream.functions import CoProcessFunction
# from pyflink.datastream.state import ValueStateDescriptor
# from pyflink.common.typeinfo import Types
# from utils import MessagePayload, NotificationService
# from datetime import datetime, timezone

# class VehicleStateProcessor(CoProcessFunction):
#     def __init__(self):
#         self.effective_soc_state = None
#         self.charging_status_state = None
#         self.soc_time = None
#         self.charging_time = None
#         # self.notification_service = None

#     def open(self, runtime_context):
        
#         soc_desc = ValueStateDescriptor("effective_soc", Types.FLOAT())
#         self.effective_soc_state = runtime_context.get_state(soc_desc)
        
#         charging_desc = ValueStateDescriptor("charging_status", Types.INT())
#         self.charging_status_state = runtime_context.get_state(charging_desc)
        
#         soc_time_desc = ValueStateDescriptor("soc_time", Types.LONG())
#         self.soc_time = runtime_context.get_state(soc_time_desc)
        
#         charging_time_desc = ValueStateDescriptor("charging_time", Types.LONG())
#         self.charging_time = runtime_context.get_state(charging_time_desc)

#         # self.notification_service = NotificationService()

#     def process_element1(self, msg: MessagePayload,ctx):
#         """Process HMI-primary stream (SOC updates)"""
#         vin = msg.vin
#         event_time = msg.event_time
#         effective_soc = float(msg.message_json.get('EffectiveSOC',None))
        
#         # Update HMI-related states
#         self.effective_soc_state.update(effective_soc)
#         self.soc_time.update(event_time)
        
#         # # Get current charging status (if available)
#         # charging_status = self.charging_status_state.value()
#         # charging_time = self.charging_time.value()
        
#         # Print HMI data with current charging status
#         print(f"[HMI Update] VIN: {vin} Event Time: {event_time} Effective SOC: {effective_soc}")
        
        
       

#     def process_element2(self, msg: MessagePayload,ctx):
#         """Process BCM-secondary stream (charging updates)"""
#         vin = msg.vin
#         event_time = msg.event_time
#         charging_status = int(msg.message_json.get('BCM_ChargingOnProgress', 0))
        
#         # Update BCM-related states
#         self.charging_status_state.update(charging_status)
#         self.charging_time.update(event_time)
        
#         # Get current SOC (if available)
#         current_soc = self.effective_soc_state.value()
#         # soc_time = self.soc_time.value()
        
#         # Print BCM data with current SOC
#         print(f""" [BCM Update] VIN: {vin} Event Time: {event_time} Charging Status: {charging_status} Current SOC: {current_soc}""")
        
        
        

     
    
    # def _evaluate_conditions(self, ctx):
    #     current_time = ctx.timer_service().current_processing_time()
        
    #     # Get current states
    #     hmi_data = self.hmi_state.value() or (None, 0)
    #     bcm_data = self.bcm_state.value() or (None, 0)
        
    #     # Extract values and timestamps
    #     current_soc, hmi_timestamp = hmi_data
    #     current_charging, bcm_timestamp = bcm_data
        
    #     # Check 1-minute validity window
    #     hmi_valid = (current_time - hmi_timestamp) <= 60000
    #     bcm_valid = (current_time - bcm_timestamp) <= 60000
        
    #     if not all([hmi_valid, bcm_valid, current_soc is not None, current_charging is not None]):
    #         return

    #     # Get last notified values
    #     last_notified = self.last_notified.value() or (None, None)
        
    #     # Check for changes
    #     if (current_soc, current_charging) != last_notified:
    #         event_time = datetime.fromtimestamp(
    #             max(hmi_timestamp, bcm_timestamp) / 1000, 
    #             tz=timezone.utc
    #         )
            
    #         # Send notifications
    #         self._check_battery_conditions(
    #             vin=ctx.get_current_key(),
    #             soc=current_soc,
    #             charging_status=current_charging,
    #             event_time=event_time
    #         )
            
    #         # Update last notified state
    #         self.last_notified.update((current_soc, current_charging))

    # def _check_battery_conditions(self, vin, soc, charging_status, event_time):
    #     """Check all notification conditions"""
    #     # Critical battery check
    #     if soc <= 20 and charging_status == 0:
    #         self._send_notification(
    #             vin=vin,
    #             message=f"[Critical] Battery at {soc}% - Please charge immediately",
    #             event_time=event_time
    #         )
        
    #     # Charging status change
    #     if self.last_notified.value():
    #         last_soc, last_charging = self.last_notified.value()
    #         if charging_status != last_charging:
    #             status = "started" if charging_status == 1 else "stopped"
    #             self._send_notification(
    #                 vin=vin,
    #                 message=f"Charging {status} at {soc}% SOC",
    #                 event_time=event_time
    #             )
        
    #     # Fully charged check (with float tolerance)
    #     if 99.9 <= soc <= 100.1:
    #         self._send_notification(
    #             vin=vin,
    #             message="Battery fully charged",
    #             event_time=event_time
    #         )

    # def _send_notification(self, vin, message, event_time):
    #     """Unified notification method"""
    #     self.notification_service.send_notification(
    #         recipient=["naveen@simpleenergy.in"],
    #         vin=vin,
    #         timestamp=event_time,
    #         message=message
    #     )





from pyflink.datastream.functions import CoProcessFunction
from pyflink.datastream.state import ValueStateDescriptor
from pyflink.common.typeinfo import Types
from utils import MessagePayload, NotificationService
from datetime import datetime, timezone

class VehicleStateProcessor(CoProcessFunction):
    def __init__(self):
        self.hmi_time_state = None
        self.bcm_time_state = None
        self.current_soc_state = None
        self.current_charging_state = None
        self.prev_charging_state = None
        self.notification_service = None

    def open(self, runtime_context):
        self.hmi_time_state = runtime_context.get_state(
            ValueStateDescriptor("hmi_event_time", Types.LONG()))
        self.bcm_time_state = runtime_context.get_state(
            ValueStateDescriptor("bcm_event_time", Types.LONG()))
        self.current_soc_state = runtime_context.get_state(
            ValueStateDescriptor("current_soc", Types.FLOAT()))
        self.current_charging_state = runtime_context.get_state(
            ValueStateDescriptor("current_charging", Types.INT()))
        self.prev_charging_state = runtime_context.get_state(
            ValueStateDescriptor("prev_charging", Types.INT()))
        self.notification_service = NotificationService()

    def process_element1(self, hmi_msg: MessagePayload, ctx):
        vin = hmi_msg.vin
        soc = float(hmi_msg.message_json.get('EffectiveSOC'))
        hmi_time = hmi_msg.event_time

        # Always keep the latest HMI event
        prev_hmi_time = self.hmi_time_state.value()
        if prev_hmi_time is None or hmi_time >= prev_hmi_time:
            self.hmi_time_state.update(hmi_time)
            self.current_soc_state.update(soc)

        bcm_time = self.bcm_time_state.value()
        if bcm_time is not None:
            self._maybe_notify(vin)

    def process_element2(self, bcm_msg: MessagePayload, ctx):
        vin = bcm_msg.vin
        charging_status = int(bcm_msg.message_json.get('BCM_ChargingOnProgress', 0))
        bcm_time = bcm_msg.event_time

        # Always keep the latest BCM event
        prev_bcm_time = self.bcm_time_state.value()
        if prev_bcm_time is None or bcm_time >= prev_bcm_time:
            self.bcm_time_state.update(bcm_time)
            prev_charging = self.current_charging_state.value()
            self.prev_charging_state.update(prev_charging if prev_charging is not None else charging_status)
            self.current_charging_state.update(charging_status)

        hmi_time = self.hmi_time_state.value()
        if hmi_time is not None:
            self._maybe_notify(vin)

    def _maybe_notify(self, vin):
        hmi_time = self.hmi_time_state.value()
        bcm_time = self.bcm_time_state.value()
        soc = self.current_soc_state.value()
        charging = self.current_charging_state.value()
        prev_charging = self.prev_charging_state.value()

        # Only proceed if both events are present and within 1 minute
        if hmi_time is not None and bcm_time is not None:
            time_diff = abs(hmi_time - bcm_time)
            if time_diff <= 60000:
                event_time = max(hmi_time, bcm_time)
                event_dt = datetime.fromtimestamp(event_time // 1000, tz=timezone.utc)
                # 1. SOC <= 20 and charger not connected
                if soc is not None and soc <= 20 and charging == 0:
                    self.output(vin, event_dt, "Critical battery level! Please plug in charger immediately.")
                # 2. SOC == 100 and charger connected
                if soc is not None and soc >= 100 and charging == 1:
                    self.output(vin, event_dt, "Battery fully charged! Please disconnect charger.")
                # 3. Charging status changed (0->1 or 1->0)
                if prev_charging is not None and charging != prev_charging:
                    status = "connected" if charging == 1 else "disconnected"
                    self.output(vin, event_dt, f"Charger {status}. Current SOC: {soc}%")
                # Clear state after notification window
                self._clear_states()

    def output(self, vin, timestamp, message):
        # try:
        #     self.notification_service.send_notification(
        #         recipient=f"{vin}@owner.com",
        #         vin=vin,
        #         timestamp=timestamp,
        #         message=message
        #     )
        # except Exception as e:
        #     print(f"Notification failed for {vin}: {str(e)}")
        print(f"Notification sent to {vin}: {message} ")

    def _clear_states(self):
        self.hmi_time_state.clear()
        self.bcm_time_state.clear()
        self.current_soc_state.clear()
        self.current_charging_state.clear()
        self.prev_charging_state.clear()
