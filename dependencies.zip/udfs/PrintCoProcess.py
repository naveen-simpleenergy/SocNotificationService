from pyflink.datastream.functions import CoProcessFunction

class PrintCoProcess(CoProcessFunction):
    def process_element1(self, value, ctx):
        print(f"[HMI Stream] {value}")
        yield value

    def process_element2(self, value, ctx):
        print(f"[BCM Stream] {value}")
        yield value