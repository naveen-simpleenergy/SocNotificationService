# In the __init__.py of the logger directory, you would import the setup_logging function:
from .log_config import setup_logging, log
